import Foundation
import PortfolioWorkbenchMobileCore

@MainActor
final class AppSettingsStore: ObservableObject {
    @Published var serverURLString: String {
        didSet {
            UserDefaults.standard.set(serverURLString, forKey: Self.serverURLKey)
        }
    }

    static let serverURLKey = "portfolio-workbench-ios.server-url"

    init() {
        self.serverURLString = UserDefaults.standard.string(forKey: Self.serverURLKey) ?? "http://127.0.0.1:8008/"
    }

    var trimmedServerURLString: String {
        serverURLString.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func makeClient() throws -> PortfolioWorkbenchAPIClient {
        guard let url = URL(string: trimmedServerURLString), url.scheme?.hasPrefix("http") == true else {
            throw PortfolioWorkbenchAPIClientError.transport("请填写可访问的服务地址，例如 http://192.168.1.10:8008/")
        }

        return PortfolioWorkbenchAPIClient(configuration: AppServerConfiguration(baseURL: url))
    }
}
