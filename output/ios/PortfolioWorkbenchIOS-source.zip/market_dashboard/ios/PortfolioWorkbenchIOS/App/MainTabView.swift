import SwiftUI

struct MainTabView: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var dashboardStore: PortfolioDashboardStore

    var body: some View {
        TabView {
            OverviewScreen()
                .tabItem {
                    Label("总览", systemImage: "chart.pie.fill")
                }

            HoldingsScreen()
                .tabItem {
                    Label("持仓", systemImage: "chart.line.uptrend.xyaxis")
                }

            AccountsScreen()
                .tabItem {
                    Label("账户", systemImage: "building.columns.fill")
                }

            SettingsScreen()
                .tabItem {
                    Label("设置", systemImage: "slider.horizontal.3")
                }
        }
        .task {
            guard dashboardStore.state.value == nil, dashboardStore.state.errorMessage == nil else {
                return
            }
            await refresh(force: false)
        }
    }

    private func refresh(force: Bool) async {
        do {
            let client = try settings.makeClient()
            await dashboardStore.load(using: client, force: force)
        } catch {
            dashboardStore.setError(error.localizedDescription)
        }
    }
}
