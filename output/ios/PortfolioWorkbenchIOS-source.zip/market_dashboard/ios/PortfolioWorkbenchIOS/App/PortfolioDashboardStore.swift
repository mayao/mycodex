import Foundation
import PortfolioWorkbenchMobileCore

@MainActor
final class PortfolioDashboardStore: ObservableObject {
    @Published private(set) var state: LoadState<MobileDashboardPayload> = .idle

    func setError(_ message: String) {
        state = .failed(message)
    }

    func load(using client: PortfolioWorkbenchAPIClient, force: Bool = false) async {
        if case .loading = state, !force {
            return
        }
        if state.value != nil, !force {
            return
        }

        state = .loading

        do {
            state = .loaded(try await client.fetchDashboard(refresh: force))
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}
