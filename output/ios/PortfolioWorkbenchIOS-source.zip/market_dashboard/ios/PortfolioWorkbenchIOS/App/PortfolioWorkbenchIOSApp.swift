import SwiftUI

@main
struct PortfolioWorkbenchIOSApp: App {
    @StateObject private var settings = AppSettingsStore()
    @StateObject private var dashboardStore = PortfolioDashboardStore()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(settings)
                .environmentObject(dashboardStore)
                .preferredColorScheme(.dark)
        }
    }
}
