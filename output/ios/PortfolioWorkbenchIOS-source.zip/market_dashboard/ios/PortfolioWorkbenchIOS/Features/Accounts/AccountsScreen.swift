import SwiftUI
import UniformTypeIdentifiers
import PortfolioWorkbenchMobileCore

struct AccountsScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var dashboardStore: PortfolioDashboardStore

    @State private var selectedAccountID = ""
    @State private var isImporting = false
    @State private var isUploading = false
    @State private var uploadMessage: String?

    var body: some View {
        NavigationStack {
            AppBackdrop {
                Group {
                    switch dashboardStore.state {
                    case .idle, .loading:
                        ProgressView("正在加载账户")
                            .tint(BrokerPalette.cyan)

                    case let .failed(message):
                        ScrollView {
                            EmptyStateCard(
                                title: "账户页暂不可用",
                                message: message,
                                actionTitle: "重试"
                            ) {
                                Task { await refresh(force: true) }
                            }
                            .padding(16)
                        }

                    case let .loaded(payload):
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 18) {
                                accountsSection(payload)
                                uploadSection(payload)
                                tradesSection(payload)
                                derivativesSection(payload)
                                updateGuideSection(payload)
                            }
                            .padding(16)
                            .padding(.bottom, 24)
                        }
                        .refreshable {
                            await refresh(force: true)
                        }
                        .task(id: payload.accounts.first?.accountId) {
                            if selectedAccountID.isEmpty {
                                selectedAccountID = payload.accounts.first?.accountId ?? ""
                            }
                        }
                    }
                }
            }
            .navigationTitle("账户")
            .appInlineNavigationTitle()
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await refresh(force: true) }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .tint(BrokerPalette.cyan)
                }
            }
        }
        .fileImporter(isPresented: $isImporting, allowedContentTypes: [.pdf]) { result in
            switch result {
            case let .success(url):
                Task { await upload(url: url) }
            case let .failure(error):
                uploadMessage = error.localizedDescription
            }
        }
    }

    private func refresh(force: Bool) async {
        do {
            let client = try settings.makeClient()
            await dashboardStore.load(using: client, force: force)
        } catch {
            dashboardStore.setError(error.localizedDescription)
        }
    }

    private func accountsSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "账户总览", subtitle: "按券商与账户压缩显示融资、衍生品和源文件状态。") {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(payload.accounts) { account in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(account.broker)
                                    .font(.headline)
                                    .foregroundStyle(BrokerPalette.ink)
                                Text(account.accountId)
                                    .font(.caption)
                                    .foregroundStyle(BrokerPalette.muted)
                            }

                            Spacer()

                            TagBadge(
                                text: account.loadStatus ?? "unknown",
                                tint: BrokerPalette.sourceStatus(account.loadStatus)
                            )
                        }

                        LabelValueRow(label: "净资产", value: NumberFormatters.hkd(account.navHkd))
                        LabelValueRow(label: "持仓市值", value: NumberFormatters.hkd(account.holdingsValueHkd))
                        LabelValueRow(
                            label: "融资占用",
                            value: NumberFormatters.hkd(account.financingHkd),
                            valueColor: account.financingHkd > 0 ? BrokerPalette.gold : BrokerPalette.ink
                        )
                        LabelValueRow(label: "头部标的", value: account.topNames ?? "暂无")

                        HStack(spacing: 8) {
                            TagBadge(text: "持仓 \(account.holdingCount)", tint: BrokerPalette.cyan)
                            TagBadge(text: "交易 \(account.tradeCount)", tint: BrokerPalette.teal)
                            TagBadge(text: "衍生品 \(account.derivativeCount)", tint: BrokerPalette.orange)
                        }

                        if let issue = account.issue, !issue.isEmpty {
                            Text(issue)
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.red)
                        } else if let fileName = account.fileName {
                            Text(fileName)
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                    }
                    .padding(14)
                    .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
            }
        }
    }

    private func uploadSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "替换结单", subtitle: "直接在手机上替换监控账户的 PDF 结单，保持网页端与移动端底层一致。") {
            VStack(alignment: .leading, spacing: 14) {
                Picker("目标账户", selection: $selectedAccountID) {
                    ForEach(payload.accounts) { account in
                        Text("\(account.broker) · \(account.accountId)").tag(account.accountId)
                    }
                }
                .pickerStyle(.menu)

                Button {
                    isImporting = true
                } label: {
                    HStack {
                        if isUploading {
                            ProgressView()
                                .tint(Color.black)
                        } else {
                            Image(systemName: "square.and.arrow.up")
                        }
                        Text(isUploading ? "正在上传" : "上传新结单 PDF")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(BrokerPalette.cyan)
                .foregroundStyle(Color.black)
                .disabled(selectedAccountID.isEmpty || isUploading)

                if let message = uploadMessage, !message.isEmpty {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(message.contains("失败") || message.contains("错误") ? BrokerPalette.red : BrokerPalette.teal)
                }

                if let source = payload.statementSources.first(where: { $0.accountId == selectedAccountID }) {
                    VStack(alignment: .leading, spacing: 8) {
                        LabelValueRow(label: "当前源", value: source.fileName)
                        LabelValueRow(label: "模式", value: source.sourceMode)
                        if let uploadedAt = source.uploadedAt {
                            LabelValueRow(label: "最近上传", value: uploadedAt)
                        }
                    }
                }
            }
        }
    }

    private func tradesSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "最近交易", subtitle: "只保留最关键字段，减少手机端表格负担。") {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(payload.recentTrades.prefix(8)) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("\(item.side) \(item.name)")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(BrokerPalette.ink)
                            Spacer()
                            Text(item.date)
                                .font(.caption)
                                .foregroundStyle(BrokerPalette.muted)
                        }

                        Text("\(item.broker) · \(item.symbol) · \(item.currency) \(NumberFormatters.grouped(item.price)) × \(NumberFormatters.grouped(item.quantity))")
                            .font(.footnote)
                            .foregroundStyle(BrokerPalette.muted)
                    }
                    .padding(12)
                    .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
            }
        }
    }

    private func derivativesSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "衍生品 / 结构化敞口", subtitle: "参考 IBKR 式的 compact 风格保留名义本金和账户归属。") {
            VStack(alignment: .leading, spacing: 12) {
                if payload.derivatives.isEmpty {
                    Text("当前没有衍生品或结构化头寸。")
                        .font(.footnote)
                        .foregroundStyle(BrokerPalette.muted)
                } else {
                    ForEach(payload.derivatives.prefix(8)) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(item.description)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(BrokerPalette.ink)

                            LabelValueRow(label: "券商", value: item.broker)
                            LabelValueRow(label: "数量", value: NumberFormatters.grouped(item.quantity))
                            LabelValueRow(label: "名义 HKD", value: NumberFormatters.grouped(item.estimatedNotionalHkd ?? 0))
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                }
            }
        }
    }

    private func updateGuideSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "使用提示", subtitle: "移动端保留最关键的运行说明和数据边界。") {
            VStack(alignment: .leading, spacing: 8) {
                ForEach(payload.updateGuide, id: \.self) { item in
                    HStack(alignment: .top, spacing: 10) {
                        Circle()
                            .fill(BrokerPalette.cyan)
                            .frame(width: 7, height: 7)
                            .padding(.top, 6)
                        Text(item)
                            .font(.subheadline)
                            .foregroundStyle(BrokerPalette.ink)
                    }
                }
            }
        }
    }

    private func upload(url: URL) async {
        guard !selectedAccountID.isEmpty else {
            uploadMessage = "请先选择目标账户。"
            return
        }

        let canAccess = url.startAccessingSecurityScopedResource()
        defer {
            if canAccess {
                url.stopAccessingSecurityScopedResource()
            }
        }

        do {
            let fileData = try Data(contentsOf: url)
            let fileName = url.lastPathComponent
            let mimeType = UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/pdf"
            let client = try settings.makeClient()

            isUploading = true
            let response = try await client.uploadStatement(
                accountID: selectedAccountID,
                fileName: fileName,
                mimeType: mimeType,
                fileData: fileData
            )
            uploadMessage = response.message
            await dashboardStore.load(using: client, force: true)
        } catch {
            uploadMessage = error.localizedDescription
        }

        isUploading = false
    }
}
