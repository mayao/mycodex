import SwiftUI
import PortfolioWorkbenchMobileCore

struct HoldingDetailScreen: View {
    let symbol: String

    @EnvironmentObject private var settings: AppSettingsStore
    @StateObject private var viewModel = HoldingDetailViewModel()

    var body: some View {
        AppBackdrop {
            Group {
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("正在加载 \(symbol)")
                        .tint(BrokerPalette.cyan)

                case let .failed(message):
                    ScrollView {
                        EmptyStateCard(
                            title: "个股详情暂不可用",
                            message: message,
                            actionTitle: "重试"
                        ) {
                            Task { await load(force: true) }
                        }
                        .padding(16)
                    }

                case let .loaded(payload):
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 18) {
                            heroSection(payload)
                            focusSection(payload)
                            signalSection(payload)
                            noteSection(payload)
                            accountSection(payload)
                            tradeSection(payload)
                            peerSection(payload)
                        }
                        .padding(16)
                        .padding(.bottom, 24)
                    }
                    .refreshable {
                        await load(force: true)
                    }
                }
            }
        }
        .navigationTitle(symbol)
        .appInlineNavigationTitle()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await load(force: true) }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .tint(BrokerPalette.cyan)
            }
        }
        .task {
            await load(force: false)
        }
    }

    private func load(force: Bool) async {
        do {
            let client = try settings.makeClient()
            await viewModel.load(symbol: symbol, using: client, force: force)
        } catch {
            viewModel.setError(error.localizedDescription)
        }
    }

    private func heroSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: payload.hero.name, subtitle: payload.hero.symbol) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 8) {
                    TagBadge(text: payload.hero.styleLabel, tint: BrokerPalette.cyan)
                    TagBadge(text: payload.hero.fundamentalLabel, tint: BrokerPalette.teal)
                    TagBadge(text: payload.hero.signalZone, tint: signalScoreColor(payload.hero.signalScore))
                }

                HStack(alignment: .lastTextBaseline) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(NumberFormatters.currency(payload.hero.currentPrice, code: payload.hero.symbol.hasSuffix(".HK") ? "HK$" : "USD"))
                            .font(.system(size: 30, weight: .heavy, design: .rounded))
                            .foregroundStyle(BrokerPalette.ink)
                            .monospacedDigit()

                        Text(payload.hero.categoryName)
                            .font(.subheadline)
                            .foregroundStyle(BrokerPalette.muted)
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 6) {
                        Text(NumberFormatters.signedPercent(payload.hero.changePct))
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(NumberFormatters.pnlColor(payload.hero.changePct))
                            .monospacedDigit()
                        Text("5D \(NumberFormatters.signedPercent(payload.hero.changePct5d))")
                            .font(.footnote)
                            .foregroundStyle(NumberFormatters.pnlColor(payload.hero.changePct5d))
                            .monospacedDigit()
                    }
                }

                Text("\(payload.sourceMeta.priceSourceLabel) · 行情日期 \(payload.sourceMeta.tradeDate)")
                    .font(.footnote)
                    .foregroundStyle(BrokerPalette.muted)

                if let newsHeadline = payload.hero.newsHeadline, !newsHeadline.isEmpty {
                    Text(newsHeadline)
                        .font(.subheadline)
                        .foregroundStyle(BrokerPalette.ink)
                }
            }
        }
    }

    private func focusSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "执行摘要", subtitle: "把桌面端的说明压成更像券商 mobile research 的短卡片。") {
            VStack(alignment: .leading, spacing: 14) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(payload.focusCards) { item in
                            VStack(alignment: .leading, spacing: 10) {
                                Text(item.label)
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(BrokerPalette.muted)
                                Text(item.value)
                                    .font(.headline.weight(.bold))
                                    .foregroundStyle(BrokerPalette.ink)
                                Text(item.detail)
                                    .font(.footnote)
                                    .foregroundStyle(BrokerPalette.muted)
                            }
                            .padding(14)
                            .frame(width: 170, alignment: .leading)
                            .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        }
                    }
                }

                bulletList(payload.executiveSummary, tint: BrokerPalette.cyan)
            }
        }
    }

    private func signalSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "信号拆解", subtitle: "保留基本面、趋势、新闻、宏观、风控五个维度的手机端判读。") {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(payload.signalRows) { row in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(row.label)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(BrokerPalette.ink)
                            Spacer()
                            Text("\(row.score)")
                                .font(.subheadline.weight(.heavy))
                                .foregroundStyle(factorToneColor(row.score))
                                .monospacedDigit()
                        }

                        GeometryReader { proxy in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 999, style: .continuous)
                                    .fill(Color.white.opacity(0.06))
                                RoundedRectangle(cornerRadius: 999, style: .continuous)
                                    .fill(factorToneColor(row.score))
                                    .frame(width: proxy.size.width * CGFloat(min(max(Double(row.score + 2) / 4.0, 0.0), 1.0)))
                            }
                        }
                        .frame(height: 8)

                        Text(row.comment)
                            .font(.footnote)
                            .foregroundStyle(BrokerPalette.muted)
                    }
                }

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(payload.priceCards) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(item.label)
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(BrokerPalette.muted)
                                Text(item.value)
                                    .font(.headline.weight(.bold))
                                    .foregroundStyle(BrokerPalette.ink)
                                if let delta = item.delta {
                                    Text(delta)
                                        .font(.footnote.weight(.semibold))
                                        .foregroundStyle(delta.contains("-") ? BrokerPalette.red : BrokerPalette.green)
                                }
                            }
                            .padding(14)
                            .frame(width: 156, alignment: .leading)
                            .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        }
                    }
                }
            }
        }
    }

    private func noteSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "定位与动作", subtitle: payload.holdingNote.categoryName) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 8) {
                    TagBadge(text: payload.holdingNote.role, tint: BrokerPalette.cyan)
                    TagBadge(text: payload.holdingNote.stance, tint: BrokerPalette.gold)
                    TagBadge(text: "权重 \(NumberFormatters.percent(payload.holdingNote.weightPct))", tint: BrokerPalette.teal)
                }

                LabelValueRow(label: "逻辑", value: payload.holdingNote.thesis)
                LabelValueRow(label: "风险", value: payload.holdingNote.risk, valueColor: BrokerPalette.gold)
                LabelValueRow(label: "动作", value: payload.holdingNote.action)
                LabelValueRow(label: "跟踪", value: payload.holdingNote.watchItems)

                Divider().overlay(BrokerPalette.line)

                Text("看多情形")
                    .font(.headline)
                    .foregroundStyle(BrokerPalette.ink)
                bulletList(payload.bullCase, tint: BrokerPalette.green)

                Text("看空情形")
                    .font(.headline)
                    .foregroundStyle(BrokerPalette.ink)
                bulletList(payload.bearCase, tint: BrokerPalette.red)

                Text("观察清单")
                    .font(.headline)
                    .foregroundStyle(BrokerPalette.ink)
                bulletList(payload.watchlist, tint: BrokerPalette.gold)
            }
        }
    }

    private func accountSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "组合映射", subtitle: "看它在不同账户里的真实落点。") {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(payload.portfolioContext) { row in
                    LabelValueRow(label: row.label, value: row.value)
                }

                Divider().overlay(BrokerPalette.line)

                ForEach(payload.accountRows) { row in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(row.label)
                                .font(.headline)
                                .foregroundStyle(BrokerPalette.ink)
                            Spacer()
                            Text(row.accountId)
                                .font(.caption)
                                .foregroundStyle(BrokerPalette.muted)
                        }

                        LabelValueRow(label: "数量", value: NumberFormatters.grouped(row.quantity))
                        LabelValueRow(label: "市值", value: NumberFormatters.grouped(row.statementValue))
                        LabelValueRow(
                            label: "盈亏率",
                            value: NumberFormatters.signedPercent(row.statementPnlPct),
                            valueColor: NumberFormatters.pnlColor(row.statementPnlPct)
                        )
                    }
                    .padding(14)
                    .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                }
            }
        }
    }

    private func tradeSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "交易与衍生品", subtitle: "把关联交易和结构化敞口收在同一页，便于手机端快速排查。") {
            VStack(alignment: .leading, spacing: 12) {
                if payload.relatedTrades.isEmpty {
                    Text("最近没有与该标的直接相关的交易。")
                        .font(.footnote)
                        .foregroundStyle(BrokerPalette.muted)
                } else {
                    ForEach(payload.relatedTrades) { trade in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("\(trade.side) \(NumberFormatters.grouped(trade.quantity ?? 0))")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(BrokerPalette.ink)
                                Spacer()
                                Text(trade.date)
                                    .font(.caption)
                                    .foregroundStyle(BrokerPalette.muted)
                            }

                            Text("\(trade.broker) · \(trade.currency) \(NumberFormatters.grouped(trade.price ?? 0))")
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                }

                if !payload.derivativeRows.isEmpty {
                    Divider().overlay(BrokerPalette.line)

                    ForEach(payload.derivativeRows) { row in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(row.description)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(BrokerPalette.ink)
                            Text("名义 HKD \(NumberFormatters.grouped(row.estimatedNotionalHkd ?? 0))")
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                    }
                }
            }
        }
    }

    private func peerSection(_ payload: HoldingDetailPayload) -> some View {
        SectionPanel(title: "同组对比", subtitle: "保留同主题 peer 对照，方便手机端横向看强弱。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.peers) { peer in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(peer.symbol)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(BrokerPalette.cyan)
                            Text(peer.name)
                                .font(.headline)
                                .foregroundStyle(BrokerPalette.ink)
                            SparklineView(points: peer.normalizedHistory.compactMap(\.price), color: signalScoreColor(peer.signalScore))
                            Text(peer.signalZone)
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(signalScoreColor(peer.signalScore))
                            Text(NumberFormatters.signedPercent(peer.changePct))
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(NumberFormatters.pnlColor(peer.changePct))
                        }
                        .padding(14)
                        .frame(width: 170, alignment: .leading)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    }
                }
            }
        }
    }

    private func bulletList(_ items: [String], tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(items, id: \.self) { item in
                HStack(alignment: .top, spacing: 10) {
                    Circle()
                        .fill(tint)
                        .frame(width: 7, height: 7)
                        .padding(.top, 6)
                    Text(item)
                        .font(.subheadline)
                        .foregroundStyle(BrokerPalette.ink)
                }
            }
        }
    }

    private func factorToneColor(_ score: Int) -> Color {
        if score >= 1 { return BrokerPalette.green }
        if score == 0 { return BrokerPalette.cyan }
        if score == -1 { return BrokerPalette.gold }
        return BrokerPalette.red
    }

    private func signalScoreColor(_ score: Int) -> Color {
        if score >= 62 { return BrokerPalette.green }
        if score >= 48 { return BrokerPalette.cyan }
        if score >= 36 { return BrokerPalette.gold }
        return BrokerPalette.red
    }
}
