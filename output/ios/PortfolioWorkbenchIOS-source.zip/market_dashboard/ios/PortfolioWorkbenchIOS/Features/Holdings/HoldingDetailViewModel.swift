import Foundation
import PortfolioWorkbenchMobileCore

@MainActor
final class HoldingDetailViewModel: ObservableObject {
    @Published private(set) var state: LoadState<HoldingDetailPayload> = .idle

    func setError(_ message: String) {
        state = .failed(message)
    }

    func load(symbol: String, using client: PortfolioWorkbenchAPIClient, force: Bool = false) async {
        if case .loading = state, !force {
            return
        }

        state = .loading

        do {
            state = .loaded(try await client.fetchHoldingDetail(symbol: symbol, refresh: force))
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}
