import SwiftUI
import PortfolioWorkbenchMobileCore

struct OverviewScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var dashboardStore: PortfolioDashboardStore

    var body: some View {
        NavigationStack {
            AppBackdrop {
                Group {
                    switch dashboardStore.state {
                    case .idle, .loading:
                        ProgressView("正在同步组合快照")
                            .tint(BrokerPalette.cyan)
                            .foregroundStyle(BrokerPalette.ink)

                    case let .failed(message):
                        ScrollView {
                            EmptyStateCard(
                                title: "总览暂不可用",
                                message: message,
                                actionTitle: "重新加载"
                            ) {
                                Task { await refresh(force: true) }
                            }
                            .padding(16)
                        }

                    case let .loaded(payload):
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 18) {
                                heroSection(payload)
                                summarySection(payload)
                                radarSection(payload)
                                driversSection(payload)
                                actionSection(payload)
                                allocationSection(payload)
                                macroSection(payload)
                                strategySection(payload)
                                spotlightSection(payload)
                            }
                            .padding(16)
                            .padding(.bottom, 28)
                        }
                        .refreshable {
                            await refresh(force: true)
                        }
                    }
                }
            }
            .navigationTitle("总览")
            .appInlineNavigationTitle()
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await refresh(force: true) }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .tint(BrokerPalette.cyan)
                }
            }
        }
    }

    private func refresh(force: Bool) async {
        do {
            let client = try settings.makeClient()
            await dashboardStore.load(using: client, force: force)
        } catch {
            dashboardStore.setError(error.localizedDescription)
        }
    }

    private func heroSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: payload.hero.title, subtitle: payload.hero.snapshotWindow) {
            VStack(alignment: .leading, spacing: 14) {
                Text(payload.hero.subtitle)
                    .font(.system(.title3, design: .rounded, weight: .bold))
                    .foregroundStyle(BrokerPalette.ink)

                Text(payload.hero.overview)
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.muted)

                HStack(spacing: 8) {
                    if let theme = payload.hero.primaryTheme {
                        TagBadge(text: theme, tint: BrokerPalette.cyan)
                    }
                    if let broker = payload.hero.primaryBroker {
                        TagBadge(text: broker, tint: BrokerPalette.teal)
                    }
                    TagBadge(text: payload.analysisDateCn, tint: BrokerPalette.gold)
                }

                VStack(alignment: .leading, spacing: 8) {
                    LabelValueRow(label: "行情层", value: payload.hero.liveNote)
                    LabelValueRow(label: "宏观层", value: payload.hero.macroNote)
                    LabelValueRow(
                        label: "结单状态",
                        value: "解析 \(payload.sourceHealth.parsedCount) / 缓存 \(payload.sourceHealth.cachedCount) / 异常 \(payload.sourceHealth.errorCount)",
                        valueColor: payload.sourceHealth.errorCount > 0 ? BrokerPalette.red : BrokerPalette.ink
                    )
                }
            }
        }
    }

    private func summarySection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "核心指标", subtitle: "移动端保持高密度，但改成横向卡片流，方便单手扫读。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.summaryCards) { card in
                        SummaryCardView(card: card)
                    }
                }
            }
        }
    }

    private func radarSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "组合雷达", subtitle: "质量、趋势、分散、杠杆与纪律，给出手机端的一屏风险判断。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.healthRadar) { item in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text(item.label)
                                    .font(.headline)
                                    .foregroundStyle(BrokerPalette.ink)
                                Spacer()
                                Text(String(format: "%.0f", item.value))
                                    .font(.system(.title3, design: .rounded, weight: .heavy))
                                    .foregroundStyle(item.value >= 70 ? BrokerPalette.green : item.value >= 45 ? BrokerPalette.gold : BrokerPalette.red)
                            }

                            Text(item.summary)
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                        .padding(14)
                        .frame(width: 190, alignment: .leading)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    }
                }
            }
        }
    }

    private func driversSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "驱动与风险", subtitle: "参考券商首页的资讯层级，把信号拆成“驱动”和“红旗”。") {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(payload.keyDrivers) { item in
                    InsightCardView(title: item.title, detail: item.detail, tone: item.tone)
                }

                Divider().overlay(BrokerPalette.line)

                ForEach(payload.riskFlags) { item in
                    InsightCardView(title: item.title, detail: item.detail, tone: item.tone)
                }
            }
        }
    }

    private func actionSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "动作中心", subtitle: payload.actionCenter.disclaimer) {
            VStack(alignment: .leading, spacing: 12) {
                Text(payload.actionCenter.headline)
                    .font(.headline)
                    .foregroundStyle(BrokerPalette.ink)

                Text(payload.actionCenter.overview)
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.muted)

                ForEach(payload.actionCenter.priorityActions) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack(alignment: .top) {
                            Circle()
                                .fill(BrokerPalette.gold)
                                .frame(width: 7, height: 7)
                                .padding(.top, 6)
                            Text(item.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(BrokerPalette.ink)
                        }

                        Text(item.detail)
                            .font(.footnote)
                            .foregroundStyle(BrokerPalette.muted)
                            .padding(.leading, 18)
                    }
                }
            }
        }
    }

    private func allocationSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "仓位分布", subtitle: "按主题、市场、券商三层压缩，保持像富途/长桥那样的组合视角切换感。") {
            VStack(alignment: .leading, spacing: 14) {
                allocationRow(title: "主题", rows: Array(payload.allocationGroups.themes.prefix(4)), tint: BrokerPalette.cyan)
                allocationRow(title: "市场", rows: Array(payload.allocationGroups.markets.prefix(4)), tint: BrokerPalette.teal)
                allocationRow(title: "券商", rows: Array(payload.allocationGroups.brokers.prefix(4)), tint: BrokerPalette.gold)
            }
        }
    }

    private func allocationRow(title: String, rows: [MobileAllocationBucket], tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(BrokerPalette.muted)

            ForEach(rows) { row in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(row.label)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(BrokerPalette.ink)
                        Spacer()
                        Text(NumberFormatters.percent(row.weightPct))
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(tint)
                            .monospacedDigit()
                    }

                    GeometryReader { proxy in
                        ZStack(alignment: .leading) {
                            RoundedRectangle(cornerRadius: 999, style: .continuous)
                                .fill(Color.white.opacity(0.06))
                            RoundedRectangle(cornerRadius: 999, style: .continuous)
                                .fill(tint.opacity(0.9))
                                .frame(width: max(18, proxy.size.width * CGFloat(min(max(row.weightPct, 0), 100) / 100)))
                        }
                    }
                    .frame(height: 8)

                    if let coreHoldings = row.coreHoldings, !coreHoldings.isEmpty {
                        Text(coreHoldings.joined(separator: "、"))
                            .font(.caption)
                            .foregroundStyle(BrokerPalette.muted)
                            .lineLimit(1)
                    }
                }
            }
        }
    }

    private func macroSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "宏观主题", subtitle: "保留热点压缩卡片，适合手机上快速扫一遍当前组合的外部变量。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.macroTopics) { item in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                TagBadge(text: item.severity, tint: BrokerPalette.severity(item.severity))
                                Spacer()
                                Text(NumberFormatters.percent(item.impactWeightPct))
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(BrokerPalette.severity(item.severity))
                                    .monospacedDigit()
                            }

                            Text(item.name)
                                .font(.headline)
                                .foregroundStyle(BrokerPalette.ink)

                            Text(item.headline)
                                .font(.subheadline)
                                .foregroundStyle(BrokerPalette.ink.opacity(0.92))
                                .lineLimit(3)

                            Text(item.summary)
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                                .lineLimit(4)
                        }
                        .padding(16)
                        .frame(width: 286, alignment: .leading)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                    }
                }
            }
        }
    }

    private func strategySection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "策略视图", subtitle: "把长文策略拆成可滑动卡片，保留关键信息密度。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.strategyViews) { item in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text(item.title)
                                    .font(.headline)
                                    .foregroundStyle(BrokerPalette.ink)
                                Spacer()
                                ToneBadge(text: item.tag, tone: item.tone)
                            }

                            Text(item.summary)
                                .font(.subheadline)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                        .padding(16)
                        .frame(width: 280, alignment: .leading)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                    }
                }
            }
        }
    }

    private func spotlightSection(_ payload: MobileDashboardPayload) -> some View {
        SectionPanel(title: "头部持仓", subtitle: "手机端只露出最高频关注的头部仓位，点击进入单票详情。") {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(Array(payload.spotlightPositions.prefix(4))) { position in
                    NavigationLink {
                        HoldingDetailScreen(symbol: position.symbol)
                    } label: {
                        PositionCompactCard(position: position)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
