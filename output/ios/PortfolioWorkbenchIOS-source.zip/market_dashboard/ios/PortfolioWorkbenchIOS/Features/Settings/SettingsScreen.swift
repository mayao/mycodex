import SwiftUI

struct SettingsScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var dashboardStore: PortfolioDashboardStore

    @FocusState private var isEditingURL: Bool
    @State private var isRefreshing = false
    @State private var refreshMessage: String?

    var body: some View {
        NavigationStack {
            AppBackdrop {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 18) {
                        connectionSection
                        architectureSection
                        referenceSection
                    }
                    .padding(16)
                    .padding(.bottom, 24)
                }
            }
            .navigationTitle("设置")
            .appInlineNavigationTitle()
        }
    }

    private var connectionSection: some View {
        SectionPanel(title: "服务连接", subtitle: "iPhone 真机访问开发机时请使用局域网地址，不要填 localhost。") {
            VStack(alignment: .leading, spacing: 14) {
                TextField("http://192.168.1.10:8008/", text: $settings.serverURLString)
                    .appURLTextEntry()
                    .focused($isEditingURL)
                    .padding(14)
                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .foregroundStyle(BrokerPalette.ink)

                Button {
                    Task { await refreshNow() }
                } label: {
                    HStack {
                        if isRefreshing {
                            ProgressView()
                                .tint(Color.black)
                        } else {
                            Image(systemName: "dot.radiowaves.left.and.right")
                        }
                        Text(isRefreshing ? "连接中" : "保存并刷新")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(BrokerPalette.cyan)
                .foregroundStyle(Color.black)

                if let refreshMessage {
                    Text(refreshMessage)
                        .font(.footnote)
                        .foregroundStyle(refreshMessage.contains("失败") || refreshMessage.contains("错误") ? BrokerPalette.red : BrokerPalette.teal)
                }
            }
        }
    }

    private var architectureSection: some View {
        SectionPanel(title: "移动端边界", subtitle: "代码分离，底层共享。") {
            VStack(alignment: .leading, spacing: 10) {
                Text("Web 与 iOS UI 独立维护；后端仍由 Python 组合分析与结单解析提供唯一真相源。")
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.ink)
                Text("移动端重点做总览压缩、持仓搜索、账户/结单替换和单票下钻。")
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.ink)
                Text("视觉上借鉴 IBKR、长桥、富途、老虎的移动信息密度，但保持你当前工作台的深色 command center 语言。")
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.ink)
            }
        }
    }

    private var referenceSection: some View {
        SectionPanel(title: "参考资料", subtitle: "用于工作台分析的外部复盘材料与本地说明。") {
            VStack(alignment: .leading, spacing: 10) {
                if case let .loaded(payload) = dashboardStore.state, !payload.referenceSources.isEmpty {
                    ForEach(payload.referenceSources) { item in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.label)
                                .font(.headline)
                                .foregroundStyle(BrokerPalette.ink)
                            Text("\(item.type.uppercased()) · \(item.fileName)")
                                .font(.footnote)
                                .foregroundStyle(BrokerPalette.muted)
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    }
                } else {
                    Text("当前未加载到参考资料，请先连接服务。")
                        .font(.subheadline)
                        .foregroundStyle(BrokerPalette.muted)
                }
            }
        }
    }

    private func refreshNow() async {
        isRefreshing = true
        isEditingURL = false

        do {
            let client = try settings.makeClient()
            await dashboardStore.load(using: client, force: true)
            refreshMessage = "已连接 \(settings.trimmedServerURLString)"
        } catch {
            dashboardStore.setError(error.localizedDescription)
            refreshMessage = error.localizedDescription
        }

        isRefreshing = false
    }
}
