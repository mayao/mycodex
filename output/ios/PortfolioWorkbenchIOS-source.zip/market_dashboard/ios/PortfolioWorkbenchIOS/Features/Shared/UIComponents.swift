import SwiftUI
import PortfolioWorkbenchMobileCore

#if canImport(UIKit)
import UIKit
#endif

enum BrokerPalette {
    static let ink = Color(red: 0.93, green: 0.96, blue: 1.0)
    static let muted = Color(red: 0.56, green: 0.65, blue: 0.78)
    static let cyan = Color(red: 0.38, green: 0.91, blue: 1.0)
    static let teal = Color(red: 0.24, green: 0.89, blue: 0.78)
    static let gold = Color(red: 1.0, green: 0.84, blue: 0.51)
    static let orange = Color(red: 1.0, green: 0.61, blue: 0.39)
    static let red = Color(red: 1.0, green: 0.45, blue: 0.45)
    static let green = Color(red: 0.13, green: 0.90, blue: 0.64)
    static let panel = Color(red: 0.05, green: 0.13, blue: 0.24, opacity: 0.94)
    static let panelStrong = Color(red: 0.03, green: 0.09, blue: 0.17, opacity: 0.98)
    static let line = Color.white.opacity(0.08)

    static func tone(_ tone: MobileTone?) -> Color {
        switch tone {
        case .up:
            return green
        case .warn:
            return gold
        case .down:
            return red
        case .neutral, .none:
            return cyan
        }
    }

    static func severity(_ severity: String) -> Color {
        switch severity {
        case "高":
            return red
        case "中":
            return orange
        case "低":
            return teal
        default:
            return cyan
        }
    }

    static func sourceStatus(_ value: String?) -> Color {
        switch value {
        case "parsed":
            return green
        case "cache":
            return gold
        case "error":
            return red
        default:
            return cyan
        }
    }
}

struct AppBackdrop<Content: View>: View {
    @ViewBuilder let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.01, green: 0.04, blue: 0.09),
                    Color(red: 0.03, green: 0.08, blue: 0.15),
                    Color(red: 0.04, green: 0.10, blue: 0.18)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            RadialGradient(
                colors: [BrokerPalette.cyan.opacity(0.26), .clear],
                center: .topTrailing,
                startRadius: 12,
                endRadius: 280
            )
            .ignoresSafeArea()

            RadialGradient(
                colors: [BrokerPalette.teal.opacity(0.18), .clear],
                center: .bottomLeading,
                startRadius: 12,
                endRadius: 260
            )
            .ignoresSafeArea()

            content
        }
    }
}

struct SectionPanel<Content: View>: View {
    let title: String
    let subtitle: String?
    @ViewBuilder let content: Content

    init(title: String, subtitle: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(.title3, design: .rounded, weight: .bold))
                    .foregroundStyle(BrokerPalette.ink)

                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.footnote)
                        .foregroundStyle(BrokerPalette.muted)
                }
            }

            content
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [BrokerPalette.panel, BrokerPalette.panelStrong],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(BrokerPalette.line, lineWidth: 1)
        )
    }
}

struct ToneBadge: View {
    let text: String
    let tone: MobileTone?

    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .foregroundStyle(BrokerPalette.tone(tone))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(BrokerPalette.tone(tone).opacity(0.14), in: Capsule())
    }
}

struct TagBadge: View {
    let text: String
    let tint: Color

    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .foregroundStyle(tint)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(tint.opacity(0.12), in: Capsule())
    }
}

struct SummaryCardView: View {
    let card: MobileSummaryCard

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                Text(card.label)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(BrokerPalette.muted)
                    .textCase(.uppercase)
                Spacer()
                Circle()
                    .fill(BrokerPalette.tone(card.tone))
                    .frame(width: 8, height: 8)
            }

            Text(card.value)
                .font(.system(.title3, design: .rounded, weight: .heavy))
                .foregroundStyle(BrokerPalette.ink)
                .monospacedDigit()

            Text(card.detail)
                .font(.footnote)
                .foregroundStyle(BrokerPalette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(width: 210, alignment: .leading)
        .background(BrokerPalette.tone(card.tone).opacity(0.08), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(BrokerPalette.tone(card.tone).opacity(0.16), lineWidth: 1)
        )
    }
}

struct InsightCardView: View {
    let title: String
    let detail: String
    let tone: MobileTone?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(BrokerPalette.tone(tone))
                    .frame(width: 6)

                VStack(alignment: .leading, spacing: 6) {
                    Text(title)
                        .font(.headline)
                        .foregroundStyle(BrokerPalette.ink)
                    Text(detail)
                        .font(.subheadline)
                        .foregroundStyle(BrokerPalette.muted)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.03), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

struct EmptyStateCard: View {
    let title: String
    let message: String
    let actionTitle: String
    let action: () -> Void

    var body: some View {
        SectionPanel(title: title, subtitle: nil) {
            VStack(alignment: .leading, spacing: 12) {
                Text(message)
                    .font(.subheadline)
                    .foregroundStyle(BrokerPalette.muted)

                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
                    .tint(BrokerPalette.cyan)
                    .foregroundStyle(Color.black)
            }
        }
    }
}

struct SparklineShape: Shape {
    let values: [Double]

    func path(in rect: CGRect) -> Path {
        var path = Path()
        guard values.count > 1, let minValue = values.min(), let maxValue = values.max() else {
            return path
        }

        let span = max(maxValue - minValue, 0.0001)

        for (index, value) in values.enumerated() {
            let x = rect.minX + CGFloat(index) / CGFloat(values.count - 1) * rect.width
            let normalized = (value - minValue) / span
            let y = rect.maxY - CGFloat(normalized) * rect.height

            if index == 0 {
                path.move(to: CGPoint(x: x, y: y))
            } else {
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }

        return path
    }
}

struct SparklineView: View {
    let points: [Double]
    let color: Color

    var body: some View {
        if points.count > 1 {
            SparklineShape(values: points)
                .stroke(color, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                .frame(width: 96, height: 34)
        } else {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(color.opacity(0.16))
                .frame(width: 96, height: 34)
                .overlay(
                    Text("NO HIST")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(color.opacity(0.8))
                )
        }
    }
}

struct PositionCompactCard: View {
    let position: MobilePosition

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(position.symbol)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(BrokerPalette.cyan)
                    Text(position.name)
                        .font(.headline)
                        .foregroundStyle(BrokerPalette.ink)
                    Text(position.categoryName)
                        .font(.caption)
                        .foregroundStyle(BrokerPalette.muted)
                        .lineLimit(1)
                }

                Spacer()

                SparklineView(points: position.sparklinePoints, color: toneColor)
            }

            HStack(spacing: 8) {
                TagBadge(text: position.signalZone ?? "中性跟踪", tint: toneColor)
                TagBadge(text: position.stance, tint: BrokerPalette.gold)
            }

            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(NumberFormatters.hkd(position.statementValueHkd))
                        .font(.system(.headline, design: .rounded, weight: .bold))
                        .foregroundStyle(BrokerPalette.ink)
                        .monospacedDigit()
                    Text("权重 \(NumberFormatters.percent(position.weightPct))")
                        .font(.footnote)
                        .foregroundStyle(BrokerPalette.muted)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text(NumberFormatters.signedPercent(position.statementPnlPct))
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(NumberFormatters.pnlColor(position.statementPnlPct))
                        .monospacedDigit()

                    if let dayChange = position.changePct {
                        Text("日内 \(NumberFormatters.signedPercent(dayChange))")
                            .font(.footnote)
                            .foregroundStyle(NumberFormatters.pnlColor(dayChange))
                            .monospacedDigit()
                    }
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(BrokerPalette.line, lineWidth: 1)
        )
    }

    private var toneColor: Color {
        switch position.signalZone {
        case "积极进攻":
            return BrokerPalette.green
        case "防守处理":
            return BrokerPalette.red
        case "中性跟踪":
            return BrokerPalette.cyan
        default:
            return BrokerPalette.gold
        }
    }
}

struct LabelValueRow: View {
    let label: String
    let value: String
    let valueColor: Color

    init(label: String, value: String, valueColor: Color = BrokerPalette.ink) {
        self.label = label
        self.value = value
        self.valueColor = valueColor
    }

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label)
                .font(.footnote)
                .foregroundStyle(BrokerPalette.muted)
            Spacer()
            Text(value)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(valueColor)
                .multilineTextAlignment(.trailing)
        }
    }
}

enum NumberFormatters {
    static func hkd(_ value: Double?) -> String {
        guard let value else { return "N/A" }
        return "HK$" + grouped(value)
    }

    static func currency(_ value: Double?, code: String) -> String {
        guard let value else { return "N/A" }
        if code.contains("$") {
            return code + grouped(value)
        }
        return "\(code) " + grouped(value)
    }

    static func grouped(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = abs(value) >= 1000 ? 0 : 2
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? String(format: "%.2f", value)
    }

    static func percent(_ value: Double?) -> String {
        guard let value else { return "N/A" }
        return String(format: "%.2f%%", value)
    }

    static func signedPercent(_ value: Double?) -> String {
        guard let value else { return "N/A" }
        return String(format: value >= 0 ? "+%.2f%%" : "%.2f%%", value)
    }

    static func pnlColor(_ value: Double?) -> Color {
        guard let value else { return BrokerPalette.muted }
        if value > 0 { return BrokerPalette.green }
        if value < 0 { return BrokerPalette.red }
        return BrokerPalette.muted
    }
}

extension View {
    @ViewBuilder
    func appInlineNavigationTitle() -> some View {
        #if canImport(UIKit)
        navigationBarTitleDisplayMode(.inline)
        #else
        self
        #endif
    }

    @ViewBuilder
    func appURLTextEntry() -> some View {
        #if canImport(UIKit)
        textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .keyboardType(.URL)
        #else
        self
        #endif
    }
}
