import Foundation

public enum MobileTone: String, Codable, Sendable {
    case up
    case warn
    case down
    case neutral
}

public struct MobileDashboardPayload: Codable, Sendable {
    public let generatedAt: String
    public let analysisDateCn: String
    public let snapshotDate: String
    public let hero: MobileDashboardHero
    public let summaryCards: [MobileSummaryCard]
    public let sourceHealth: MobileSourceHealth
    public let keyDrivers: [MobileInsightCard]
    public let riskFlags: [MobileInsightCard]
    public let actionCenter: MobileActionCenter
    public let healthRadar: [MobileRadarMetric]
    public let allocationGroups: MobileAllocationGroups
    public let macroTopics: [MobileMacroTopic]
    public let strategyViews: [MobileStrategyCard]
    public let positions: [MobilePosition]
    public let spotlightPositions: [MobilePosition]
    public let accounts: [MobileAccount]
    public let recentTrades: [MobileTrade]
    public let derivatives: [MobileDerivative]
    public let statementSources: [MobileStatementSource]
    public let referenceSources: [MobileReferenceSource]
    public let updateGuide: [String]
}

public struct MobileDashboardHero: Codable, Sendable {
    public let title: String
    public let subtitle: String
    public let overview: String
    public let snapshotWindow: String
    public let liveNote: String
    public let macroNote: String
    public let primaryTheme: String?
    public let primaryBroker: String?
}

public struct MobileSummaryCard: Codable, Sendable, Identifiable {
    public let label: String
    public let value: String
    public let detail: String
    public let tone: MobileTone

    public var id: String { label }
}

public struct MobileSourceHealth: Codable, Sendable {
    public let parsedCount: Int
    public let cachedCount: Int
    public let errorCount: Int
}

public struct MobileInsightCard: Codable, Sendable, Identifiable {
    public let title: String
    public let detail: String
    public let tone: MobileTone?

    public var id: String { title + String(detail.prefix(20)) }
}

public struct MobileActionCenter: Codable, Sendable {
    public let headline: String
    public let overview: String
    public let priorityActions: [MobilePriorityAction]
    public let disclaimer: String
}

public struct MobilePriorityAction: Codable, Sendable, Identifiable {
    public let title: String
    public let detail: String

    public var id: String { title + String(detail.prefix(20)) }
}

public struct MobileRadarMetric: Codable, Sendable, Identifiable {
    public let label: String
    public let value: Double
    public let summary: String

    public var id: String { label }
}

public struct MobileAllocationGroups: Codable, Sendable {
    public let themes: [MobileAllocationBucket]
    public let markets: [MobileAllocationBucket]
    public let brokers: [MobileAllocationBucket]
}

public struct MobileAllocationBucket: Codable, Sendable, Identifiable {
    public let label: String
    public let valueHkd: Double?
    public let weightPct: Double
    public let count: Int?
    public let coreHoldings: [String]?
    public let coreSymbols: [String]?

    public var id: String { label }
}

public struct MobileMacroTopic: Codable, Sendable, Identifiable {
    public let rawId: String?
    public let name: String
    public let severity: String
    public let summary: String
    public let headline: String
    public let impactLabels: String
    public let score: Int
    public let source: String?
    public let publishedAt: String?
    public let impactWeightPct: Double

    public var id: String { rawId ?? name }

    enum CodingKeys: String, CodingKey {
        case rawId = "id"
        case name
        case severity
        case summary
        case headline
        case impactLabels
        case score
        case source
        case publishedAt
        case impactWeightPct
    }
}

public struct MobileStrategyCard: Codable, Sendable, Identifiable {
    public let title: String
    public let tag: String
    public let tone: MobileTone
    public let summary: String

    public var id: String { title }
}

public struct MobilePosition: Codable, Sendable, Identifiable {
    public let symbol: String
    public let name: String
    public let nameEn: String?
    public let market: String
    public let currency: String
    public let categoryName: String
    public let styleLabel: String
    public let fundamentalLabel: String
    public let weightPct: Double
    public let statementValueHkd: Double
    public let statementPnlPct: Double?
    public let statementPnlHkd: Double?
    public let currentPrice: Double?
    public let changePct: Double?
    public let changePct5d: Double?
    public let tradeDate: String?
    public let signalScore: Int?
    public let signalZone: String?
    public let trendState: String?
    public let positionLabel: String?
    public let macroSignal: String?
    public let newsSignal: String?
    public let accountCount: Int?
    public let stance: String
    public let role: String
    public let summary: String?
    public let action: String?
    public let watchItems: String?
    public let sparklinePoints: [Double]

    public var id: String { symbol }
}

public struct MobileAccount: Codable, Sendable, Identifiable {
    public let accountId: String
    public let broker: String
    public let statementDate: String
    public let baseCurrency: String
    public let navHkd: Double
    public let holdingsValueHkd: Double
    public let financingHkd: Double
    public let holdingCount: Int
    public let tradeCount: Int
    public let derivativeCount: Int
    public let riskNotes: [String]
    public let topNames: String?
    public let sourceMode: String?
    public let uploadedAt: String?
    public let loadStatus: String?
    public let issue: String?
    public let fileName: String?
    public let fileExists: Bool?
    public let statementType: String?

    public var id: String { accountId }
}

public struct MobileTrade: Codable, Sendable, Identifiable {
    public let date: String
    public let symbol: String
    public let name: String
    public let side: String
    public let quantity: Double
    public let price: Double
    public let currency: String
    public let broker: String
    public let accountId: String

    public var id: String { "\(date)-\(symbol)-\(broker)-\(quantity)" }
}

public struct MobileDerivative: Codable, Sendable, Identifiable {
    public let symbol: String
    public let description: String
    public let currency: String
    public let quantity: Double
    public let marketValue: Double?
    public let unrealizedPnl: Double?
    public let estimatedNotional: Double?
    public let estimatedNotionalHkd: Double?
    public let underlyings: [String]
    public let broker: String
    public let accountId: String

    public var id: String { description + accountId }
}

public struct MobileStatementSource: Codable, Sendable, Identifiable {
    public let accountId: String
    public let broker: String
    public let fileExists: Bool
    public let fileName: String
    public let issue: String?
    public let loadStatus: String
    public let sourceMode: String
    public let statementDate: String?
    public let statementType: String
    public let uploadedAt: String?

    public var id: String { accountId }
}

public struct MobileReferenceSource: Codable, Sendable, Identifiable {
    public let label: String
    public let type: String
    public let fileName: String

    public var id: String { label + fileName }
}

public struct HoldingDetailPayload: Codable, Sendable {
    public let generatedAt: String
    public let analysisDateCn: String
    public let shareMode: Bool
    public let hero: HoldingDetailHero
    public let sourceMeta: HoldingDetailSourceMeta
    public let executiveSummary: [String]
    public let focusCards: [HoldingDetailFocusCard]
    public let signalRows: [HoldingDetailSignalRow]
    public let signalMatrix: HoldingDetailSignalMatrix
    public let portfolioContext: [HoldingDetailLabelValue]
    public let priceCards: [HoldingDetailPriceCard]
    public let accountRows: [HoldingDetailAccountRow]
    public let relatedTrades: [HoldingDetailTradeRow]
    public let derivativeRows: [HoldingDetailDerivativeRow]
    public let bullCase: [String]
    public let bearCase: [String]
    public let watchlist: [String]
    public let actionPlan: [String]
    public let peers: [HoldingDetailPeer]
    public let history: [HoldingDetailSeriesPoint]
    public let comparisonHistory: [HoldingDetailComparisonRow]
    public let holdingNote: HoldingDetailNote
}

public struct HoldingDetailHero: Codable, Sendable {
    public let symbol: String
    public let name: String
    public let categoryName: String
    public let styleLabel: String
    public let fundamentalLabel: String
    public let signalScore: Int
    public let signalZone: String
    public let trendState: String
    public let positionLabel: String
    public let macroSignal: String
    public let newsSignal: String
    public let currentPrice: Double?
    public let changePct: Double?
    public let changePct5d: Double?
    public let tradeDate: String?
    public let priceSource: String
    public let priceSourceLabel: String
    public let newsHeadline: String?
}

public struct HoldingDetailSourceMeta: Codable, Sendable {
    public let priceSourceLabel: String
    public let liveUpdatedAt: String?
    public let macroUpdatedAt: String?
    public let tradeDate: String
}

public struct HoldingDetailFocusCard: Codable, Sendable, Identifiable {
    public let label: String
    public let value: String
    public let detail: String

    public var id: String { label }
}

public struct HoldingDetailSignalRow: Codable, Sendable, Identifiable {
    public let label: String
    public let score: Int
    public let comment: String

    public var id: String { label }
}

public struct HoldingDetailSignalMatrix: Codable, Sendable {
    public let columns: [HoldingDetailSignalMatrixColumn]
    public let rows: [HoldingDetailSignalMatrixRow]
}

public struct HoldingDetailSignalMatrixColumn: Codable, Sendable, Identifiable {
    public let key: String
    public let label: String

    public var id: String { key }
}

public struct HoldingDetailSignalMatrixRow: Codable, Sendable, Identifiable {
    public let symbol: String
    public let name: String
    public let isTarget: Bool
    public let signalScore: Int
    public let signalZone: String
    public let trendState: String
    public let cells: [HoldingDetailSignalMatrixCell]

    public var id: String { symbol }
}

public struct HoldingDetailSignalMatrixCell: Codable, Sendable, Identifiable {
    public let label: String
    public let score: Int

    public var id: String { label }
}

public struct HoldingDetailLabelValue: Codable, Sendable, Identifiable {
    public let label: String
    public let value: String

    public var id: String { label + value }
}

public struct HoldingDetailPriceCard: Codable, Sendable, Identifiable {
    public let label: String
    public let value: String
    public let delta: String?

    public var id: String { label }
}

public struct HoldingDetailAccountRow: Codable, Sendable, Identifiable {
    public let label: String
    public let accountId: String
    public let quantity: Double
    public let statementValue: Double
    public let statementPnlPct: Double?

    public var id: String { accountId }
}

public struct HoldingDetailTradeRow: Codable, Sendable, Identifiable {
    public let date: String
    public let side: String
    public let broker: String
    public let quantity: Double?
    public let price: Double?
    public let currency: String

    public var id: String { "\(date)-\(broker)-\(quantity ?? 0)" }
}

public struct HoldingDetailDerivativeRow: Codable, Sendable, Identifiable {
    public let symbol: String
    public let description: String
    public let estimatedNotionalHkd: Double?

    public var id: String { description + symbol }
}

public struct HoldingDetailPeer: Codable, Sendable, Identifiable {
    public let symbol: String
    public let name: String
    public let signalScore: Int
    public let trendState: String
    public let currentPrice: Double?
    public let changePct: Double?
    public let normalizedHistory: [HoldingDetailSeriesPoint]
    public let factorScores: [String: Int]
    public let signalZone: String

    public var id: String { symbol }
}

public struct HoldingDetailSeriesPoint: Codable, Sendable, Identifiable {
    public let date: String
    public let price: Double?

    public var id: String { date }
}

public struct HoldingDetailComparisonRow: Codable, Sendable, Identifiable {
    public let symbol: String
    public let name: String
    public let isTarget: Bool
    public let points: [HoldingDetailSeriesPoint]

    public var id: String { symbol }
}

public struct HoldingDetailNote: Codable, Sendable {
    public let symbol: String
    public let name: String
    public let weightPct: Double
    public let role: String
    public let stance: String
    public let thesis: String
    public let watchItems: String
    public let risk: String
    public let action: String
    public let currentPrice: Double?
    public let changePct: Double?
    public let positionLabel: String?
    public let trendState: String?
    public let macroSignal: String?
    public let newsSignal: String?
    public let fundamentalLabel: String?
    public let signalScore: Int?
    public let signalZone: String?
    public let statementPnlPct: Double?
    public let statementValueHkd: Double
    public let categoryName: String
}

public struct StatementUploadEnvelope: Codable, Sendable {
    public let message: String
}
