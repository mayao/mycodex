import Foundation

public struct AppServerConfiguration: Sendable, Equatable {
    public var baseURL: URL

    public init(baseURL: URL) {
        self.baseURL = baseURL
    }
}

public enum PortfolioWorkbenchAPIClientError: LocalizedError, Sendable {
    case invalidResponse
    case server(statusCode: Int, message: String)
    case transport(String)

    public var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "服务响应格式无效。"
        case let .server(_, message):
            return message
        case let .transport(message):
            return message
        }
    }
}

public protocol URLSessioning: Sendable {
    func data(for request: URLRequest) async throws -> (Data, URLResponse)
}

extension URLSession: URLSessioning {}

private struct APIErrorEnvelope: Decodable {
    struct APIErrorPayload: Decodable {
        let id: String?
        let message: String
    }

    enum APIError: Decodable {
        case message(String)
        case payload(APIErrorPayload)

        init(from decoder: Decoder) throws {
            let singleValueContainer = try decoder.singleValueContainer()
            if let message = try? singleValueContainer.decode(String.self) {
                self = .message(message)
                return
            }

            let payload = try singleValueContainer.decode(APIErrorPayload.self)
            self = .payload(payload)
        }

        var message: String {
            switch self {
            case let .message(message):
                return message
            case let .payload(payload):
                return payload.message
            }
        }
    }

    let error: APIError
}

public final class PortfolioWorkbenchAPIClient: @unchecked Sendable {
    private let configuration: AppServerConfiguration
    private let session: URLSessioning
    private let decoder: JSONDecoder

    public init(
        configuration: AppServerConfiguration,
        session: URLSessioning = URLSession.shared
    ) {
        self.configuration = configuration
        self.session = session

        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        self.decoder = decoder
    }

    public func fetchDashboard(refresh: Bool = false) async throws -> MobileDashboardPayload {
        let query = refresh ? [URLQueryItem(name: "refresh", value: "1")] : []
        return try await send(path: "api/mobile/dashboard", query: query)
    }

    public func fetchHoldingDetail(symbol: String, refresh: Bool = false) async throws -> HoldingDetailPayload {
        var query = [URLQueryItem(name: "symbol", value: symbol)]
        if refresh {
            query.append(URLQueryItem(name: "refresh", value: "1"))
        }
        return try await send(path: "api/mobile/stock-detail", query: query)
    }

    public func uploadStatement(
        accountID: String,
        fileName: String,
        mimeType: String,
        fileData: Data
    ) async throws -> StatementUploadEnvelope {
        var body = MultipartFormDataBody()
        body.appendField(name: "account_id", value: accountID)
        body.appendFile(name: "statement_file", fileName: fileName, mimeType: mimeType, fileData: fileData)
        body.finalize()

        var request = makeRequest(path: "api/mobile/upload-statement", method: "POST")
        request.setValue("multipart/form-data; boundary=\(body.boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body.data

        return try await send(request: request)
    }

    private func send<T: Decodable>(path: String, query: [URLQueryItem] = []) async throws -> T {
        try await send(request: makeRequest(path: path, method: "GET", query: query))
    }

    private func send<T: Decodable>(request: URLRequest) async throws -> T {
        let payload: Data
        let response: URLResponse

        do {
            (payload, response) = try await session.data(for: request)
        } catch {
            throw PortfolioWorkbenchAPIClientError.transport(error.localizedDescription)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw PortfolioWorkbenchAPIClientError.invalidResponse
        }

        guard (200 ..< 300).contains(httpResponse.statusCode) else {
            if let envelope = try? decoder.decode(APIErrorEnvelope.self, from: payload) {
                throw PortfolioWorkbenchAPIClientError.server(statusCode: httpResponse.statusCode, message: envelope.error.message)
            }

            throw PortfolioWorkbenchAPIClientError.server(
                statusCode: httpResponse.statusCode,
                message: "请求失败，状态码 \(httpResponse.statusCode)。"
            )
        }

        do {
            return try decoder.decode(T.self, from: payload)
        } catch {
            throw PortfolioWorkbenchAPIClientError.transport("数据解析失败: \(error.localizedDescription)")
        }
    }

    private func makeRequest(path: String, method: String, query: [URLQueryItem] = []) -> URLRequest {
        let url = makeURL(path: path, query: query)
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 45
        return request
    }

    private func makeURL(path: String, query: [URLQueryItem]) -> URL {
        let baseURL = configuration.baseURL.appending(path: path)
        guard !query.isEmpty else {
            return baseURL
        }

        var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false)
        components?.queryItems = query
        return components?.url ?? baseURL
    }
}
