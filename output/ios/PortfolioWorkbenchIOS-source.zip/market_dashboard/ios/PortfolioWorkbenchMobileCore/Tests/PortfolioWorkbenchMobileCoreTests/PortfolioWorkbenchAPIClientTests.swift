import Foundation
import XCTest
@testable import PortfolioWorkbenchMobileCore

final class PortfolioWorkbenchAPIClientTests: XCTestCase {
    func testDecodesDashboardPayload() async throws {
        let session = MockSession(
            statusCode: 200,
            body: """
            {
              "generated_at": "2026-03-10T12:00:00.000Z",
              "analysis_date_cn": "2026年3月10日",
              "snapshot_date": "2026-03-08",
              "hero": {
                "title": "个人投资工作台",
                "subtitle": "headline",
                "overview": "overview",
                "snapshot_window": "2026-03-01 至 2026-03-08",
                "live_note": "cache",
                "macro_note": "macro",
                "primary_theme": "港股互联网",
                "primary_broker": "Longbridge"
              },
              "summary_cards": [
                { "label": "净资产", "value": "HK$1,000,000", "detail": "detail", "tone": "up" }
              ],
              "source_health": { "parsed_count": 0, "cached_count": 5, "error_count": 0 },
              "key_drivers": [
                { "title": "driver", "detail": "detail", "tone": "warn" }
              ],
              "risk_flags": [
                { "title": "risk", "detail": "detail", "tone": "down" }
              ],
              "action_center": {
                "headline": "headline",
                "overview": "overview",
                "priority_actions": [
                  { "title": "减仓", "detail": "处理弱势仓位" }
                ],
                "disclaimer": "disclaimer"
              },
              "health_radar": [
                { "label": "质量", "value": 82.1, "summary": "summary" }
              ],
              "allocation_groups": {
                "themes": [
                  { "label": "港股互联网", "value_hkd": 1000, "weight_pct": 40.5, "count": 3, "core_holdings": ["腾讯"], "core_symbols": ["00700.HK"] }
                ],
                "markets": [],
                "brokers": []
              },
              "macro_topics": [
                { "id": "macro-1", "name": "贸易与出口管制", "severity": "高", "summary": "summary", "headline": "headline", "impact_labels": "AI", "score": -2, "source": "Reuters", "published_at": "2026-03-08", "impact_weight_pct": 66.67 }
              ],
              "strategy_views": [
                { "title": "质量复利", "tag": "权重 30%", "tone": "up", "summary": "summary" }
              ],
              "positions": [
                {
                  "symbol": "00700.HK",
                  "name": "腾讯控股",
                  "name_en": "Tencent",
                  "market": "HK",
                  "currency": "HKD",
                  "category_name": "港股互联网",
                  "style_label": "核心资产",
                  "fundamental_label": "强",
                  "weight_pct": 18.69,
                  "statement_value_hkd": 2015718,
                  "statement_pnl_pct": 26.46,
                  "statement_pnl_hkd": 378290.16,
                  "current_price": 519,
                  "change_pct": 3.39,
                  "change_pct_5d": 0.19,
                  "trade_date": "2026-03-08",
                  "signal_score": 58,
                  "signal_zone": "中性跟踪",
                  "trend_state": "弱势下行",
                  "position_label": "区间低位",
                  "macro_signal": "中性",
                  "news_signal": "中性",
                  "account_count": 3,
                  "stance": "持有但控上限",
                  "role": "核心底仓",
                  "summary": "summary",
                  "action": "action",
                  "watch_items": "游戏审批",
                  "sparkline_points": [100, 102, 101]
                }
              ],
              "spotlight_positions": [],
              "accounts": [],
              "recent_trades": [],
              "derivatives": [],
              "statement_sources": [],
              "reference_sources": [],
              "update_guide": ["guide"]
            }
            """
        )
        let client = PortfolioWorkbenchAPIClient(
            configuration: AppServerConfiguration(baseURL: URL(string: "http://localhost:8008/")!),
            session: session
        )

        let payload = try await client.fetchDashboard()

        XCTAssertEqual(payload.summaryCards.count, 1)
        XCTAssertEqual(payload.positions.first?.symbol, "00700.HK")
        XCTAssertEqual(payload.macroTopics.first?.id, "macro-1")
    }

    func testBuildsMultipartUploadRequest() async throws {
        let session = MockSession(
            statusCode: 200,
            body: """
            { "message": "uploaded" }
            """
        )
        let client = PortfolioWorkbenchAPIClient(
            configuration: AppServerConfiguration(baseURL: URL(string: "http://localhost:8008/")!),
            session: session
        )

        let response = try await client.uploadStatement(
            accountID: "tiger_1",
            fileName: "statement.pdf",
            mimeType: "application/pdf",
            fileData: Data("pdf".utf8)
        )

        XCTAssertEqual(response.message, "uploaded")
        XCTAssertNotNil(session.lastRequest)
        XCTAssertTrue((session.lastRequest?.value(forHTTPHeaderField: "Content-Type") ?? "").contains("multipart/form-data"))
        let body = String(data: session.lastRequest?.httpBody ?? Data(), encoding: .utf8) ?? ""
        XCTAssertTrue(body.contains("name=\"account_id\""))
        XCTAssertTrue(body.contains("name=\"statement_file\"; filename=\"statement.pdf\""))
    }

    func testDecodesHoldingDetailPayload() async throws {
        let session = MockSession(
            statusCode: 200,
            body: """
            {
              "generated_at": "2026-03-10T12:00:00.000Z",
              "analysis_date_cn": "2026年3月10日",
              "share_mode": false,
              "hero": {
                "symbol": "00700.HK",
                "name": "腾讯控股",
                "category_name": "港股互联网",
                "style_label": "核心资产",
                "fundamental_label": "强",
                "signal_score": 58,
                "signal_zone": "中性跟踪",
                "trend_state": "弱势下行",
                "position_label": "区间低位",
                "macro_signal": "中性",
                "news_signal": "中性",
                "current_price": 519,
                "change_pct": 3.39,
                "change_pct_5d": 0.19,
                "trade_date": "2026-03-08",
                "price_source": "cache",
                "price_source_label": "本地日更快照",
                "news_headline": "headline"
              },
              "source_meta": {
                "price_source_label": "本地日更快照",
                "live_updated_at": "2026-03-08T10:00:00Z",
                "macro_updated_at": "2026-03-08T10:00:00Z",
                "trade_date": "2026-03-08"
              },
              "executive_summary": ["summary"],
              "focus_cards": [
                { "label": "行情状态", "value": "2026-03-08", "detail": "cache" }
              ],
              "signal_rows": [
                { "label": "基本面", "score": 2, "comment": "comment" }
              ],
              "signal_matrix": {
                "columns": [{ "key": "fundamental", "label": "基本面" }],
                "rows": [{
                  "symbol": "00700.HK",
                  "name": "腾讯控股",
                  "is_target": true,
                  "signal_score": 58,
                  "signal_zone": "中性跟踪",
                  "trend_state": "弱势下行",
                  "cells": [{ "label": "基本面", "score": 2 }]
                }]
              },
              "portfolio_context": [
                { "label": "组合定位", "value": "核心底仓" }
              ],
              "price_cards": [
                { "label": "当前价格", "value": "HK$519.00", "delta": "+3.39%" }
              ],
              "account_rows": [
                { "label": "Tiger", "account_id": "tiger_1", "quantity": 100, "statement_value": 51900, "statement_pnl_pct": 5.2 }
              ],
              "related_trades": [
                { "date": "2026-03-06", "side": "买入", "broker": "Tiger", "quantity": 100, "price": 500, "currency": "HKD" }
              ],
              "derivative_rows": [
                { "symbol": "00700.HK", "description": "结构性产品", "estimated_notional_hkd": 50000 }
              ],
              "bull_case": ["bull"],
              "bear_case": ["bear"],
              "watchlist": ["watch"],
              "action_plan": ["action"],
              "peers": [
                {
                  "symbol": "09988.HK",
                  "name": "阿里巴巴-W",
                  "signal_score": 52,
                  "trend_state": "弱势下行",
                  "current_price": 120.5,
                  "change_pct": 1.2,
                  "normalized_history": [
                    { "date": "2026-03-01", "price": 100 },
                    { "date": "2026-03-02", "price": 101 }
                  ],
                  "factor_scores": { "fundamental": 1 },
                  "signal_zone": "中性跟踪"
                }
              ],
              "history": [
                { "date": "2026-03-01", "price": 500 }
              ],
              "comparison_history": [
                {
                  "symbol": "00700.HK",
                  "name": "腾讯控股",
                  "is_target": true,
                  "points": [{ "date": "2026-03-01", "price": 100 }]
                }
              ],
              "holding_note": {
                "symbol": "00700.HK",
                "name": "腾讯控股",
                "weight_pct": 18.69,
                "role": "核心底仓",
                "stance": "持有但控上限",
                "thesis": "thesis",
                "watch_items": "watch",
                "risk": "risk",
                "action": "action",
                "current_price": 519,
                "change_pct": 3.39,
                "position_label": "区间低位",
                "trend_state": "弱势下行",
                "macro_signal": "中性",
                "news_signal": "中性",
                "fundamental_label": "强",
                "signal_score": 58,
                "signal_zone": "中性跟踪",
                "statement_pnl_pct": 26.46,
                "statement_value_hkd": 2015718,
                "category_name": "港股互联网"
              }
            }
            """
        )
        let client = PortfolioWorkbenchAPIClient(
            configuration: AppServerConfiguration(baseURL: URL(string: "http://localhost:8008/")!),
            session: session
        )

        let payload = try await client.fetchHoldingDetail(symbol: "00700.HK")

        XCTAssertEqual(payload.hero.symbol, "00700.HK")
        XCTAssertEqual(payload.peers.first?.normalizedHistory.count, 2)
        XCTAssertEqual(payload.comparisonHistory.first?.points.first?.price, 100)
    }

    func testSurfacesStringServerErrors() async throws {
        let session = MockSession(
            statusCode: 400,
            body: """
            { "error": "缺少股票代码。" }
            """
        )
        let client = PortfolioWorkbenchAPIClient(
            configuration: AppServerConfiguration(baseURL: URL(string: "http://localhost:8008/")!),
            session: session
        )

        do {
            _ = try await client.fetchHoldingDetail(symbol: "")
            XCTFail("Expected server error")
        } catch let error as PortfolioWorkbenchAPIClientError {
            guard case let .server(statusCode, message) = error else {
                XCTFail("Unexpected error \(error)")
                return
            }

            XCTAssertEqual(statusCode, 400)
            XCTAssertEqual(message, "缺少股票代码。")
        }
    }
}

private final class MockSession: URLSessioning, @unchecked Sendable {
    private let statusCode: Int
    private let body: String
    var lastRequest: URLRequest?

    init(statusCode: Int, body: String) {
        self.statusCode = statusCode
        self.body = body
    }

    func data(for request: URLRequest) async throws -> (Data, URLResponse) {
        lastRequest = request
        return (
            Data(body.utf8),
            HTTPURLResponse(
                url: request.url ?? URL(string: "http://localhost")!,
                statusCode: statusCode,
                httpVersion: nil,
                headerFields: ["Content-Type": "application/json"]
            )!
        )
    }
}
