#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
IOS_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT_PATH="$IOS_DIR/PortfolioWorkbenchIOS.xcodeproj"
SCHEME="PortfolioWorkbenchIOS"

TEAM_ID="${TEAM_ID:-${1:-}}"
DEVICE_UDID="${DEVICE_UDID:-${2:-}}"
BUNDLE_ID="${BUNDLE_ID:-}"
CONFIGURATION="${CONFIGURATION:-Debug}"

if [[ -z "$TEAM_ID" ]]; then
  echo "Missing TEAM_ID."
  echo "Usage: TEAM_ID=<your_team_id> $0 [TEAM_ID] [DEVICE_UDID]"
  exit 1
fi

if [[ -z "$BUNDLE_ID" ]]; then
  BUNDLE_ID="com.${TEAM_ID,,}.PortfolioWorkbenchIOS"
fi

if ! command -v xcodegen >/dev/null 2>&1; then
  echo "xcodegen is required. Install with: brew install xcodegen"
  exit 1
fi

if [[ -z "$DEVICE_UDID" ]]; then
  DEVICE_UDID="$(
    xcrun devicectl list devices 2>/dev/null \
      | awk '/^[[:space:]]+[0-9A-F-]{8,}/ {print $1; exit}'
  )"
fi

if [[ -z "$DEVICE_UDID" ]]; then
  echo "No trusted iPhone found via devicectl."
  echo "Before retrying:"
  echo "1. Connect the iPhone with USB."
  echo "2. Tap Trust on the phone."
  echo "3. Enable Developer Mode on the phone if prompted."
  echo "4. Make sure Xcode is signed in with your Apple ID."
  exit 1
fi

echo "== Generating project =="
cd "$IOS_DIR"
xcodegen generate

echo
echo "== Building for iPhone =="
xcodebuild \
  -project "$PROJECT_PATH" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -destination "generic/platform=iOS" \
  -allowProvisioningUpdates \
  -allowProvisioningDeviceRegistration \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  build

APP_PATH="$IOS_DIR/build/${CONFIGURATION}-iphoneos/${SCHEME}.app"

if [[ ! -d "$APP_PATH" ]]; then
  echo "Built app not found at: $APP_PATH"
  exit 1
fi

echo
echo "== Installing on device $DEVICE_UDID =="
xcrun devicectl device install app --device "$DEVICE_UDID" "$APP_PATH"

echo
echo "== Launching =="
xcrun devicectl device process launch --device "$DEVICE_UDID" "$BUNDLE_ID"

echo
echo "Installed successfully."
echo "Bundle ID: $BUNDLE_ID"
echo "App path: $APP_PATH"
