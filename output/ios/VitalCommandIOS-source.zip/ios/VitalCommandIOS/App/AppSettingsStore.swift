import Foundation
import SwiftUI
import VitalCommandMobileCore

@MainActor
final class AppSettingsStore: ObservableObject {
    @Published var serverURLString: String {
        didSet {
            UserDefaults.standard.set(serverURLString, forKey: Self.serverURLKey)
        }
    }

    static let serverURLKey = "vital-command.server-url"

    init() {
        self.serverURLString = UserDefaults.standard.string(forKey: Self.serverURLKey) ?? "http://192.168.1.10:3000/"
    }

    var trimmedServerURLString: String {
        serverURLString.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func makeClient() throws -> HealthAPIClient {
        guard let url = URL(string: trimmedServerURLString), url.scheme?.hasPrefix("http") == true else {
            throw HealthAPIClientError.transport("请填写可访问的服务地址，例如 http://192.168.1.10:3000/")
        }

        return HealthAPIClient(configuration: AppServerConfiguration(baseURL: url))
    }
}
