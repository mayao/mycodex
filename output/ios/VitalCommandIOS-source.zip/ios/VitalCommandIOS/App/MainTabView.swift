import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeScreen()
                .tabItem {
                    Label("总览", systemImage: "heart.text.square")
                }

            TrendsScreen()
                .tabItem {
                    Label("趋势", systemImage: "waveform.path.ecg")
                }

            ReportsScreen()
                .tabItem {
                    Label("报告", systemImage: "doc.text")
                }

            DataHubScreen()
                .tabItem {
                    Label("数据", systemImage: "tray.full")
                }
        }
    }
}
