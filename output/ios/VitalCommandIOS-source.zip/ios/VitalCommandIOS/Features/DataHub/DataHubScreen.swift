import SwiftUI
import UniformTypeIdentifiers
import VitalCommandMobileCore

struct DataHubScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @StateObject private var viewModel = DataHubViewModel()
    @State private var isImporterPresented = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    importSection
                    privacySection
                }
                .padding(16)
            }
            .background(Color.appGroupedBackground)
            .navigationTitle("数据")
        }
        .task(id: settings.trimmedServerURLString) {
            await reload()
        }
        .fileImporter(
            isPresented: $isImporterPresented,
            allowedContentTypes: [.commaSeparatedText, .spreadsheet, .data]
        ) { result in
            Task {
                await handleImportSelection(result)
            }
        }
    }

    private var importSection: some View {
        SectionCard(title: "导入数据", subtitle: "手机端用文件选择器替代 Web 上传面板，避免表单拥挤。") {
            VStack(alignment: .leading, spacing: 14) {
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("正在读取导入配置")

                case let .failed(message):
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red)

                case let .loaded(options):
                    Picker("导入类型", selection: $viewModel.selectedImporter) {
                        ForEach(options) { option in
                            Text(option.title).tag(option.key)
                        }
                    }
                    .pickerStyle(.segmented)

                    if let current = options.first(where: { $0.key == viewModel.selectedImporter }) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(current.description)
                                .font(.subheadline)
                            ForEach(current.hints, id: \.self) { hint in
                                HStack(alignment: .top, spacing: 8) {
                                    Circle()
                                        .fill(Color.accentColor)
                                        .frame(width: 6, height: 6)
                                        .padding(.top, 7)
                                    Text(hint)
                                        .font(.footnote)
                                }
                            }
                        }
                    }

                    Button("选择文件并上传") {
                        isImporterPresented = true
                    }
                    .buttonStyle(.borderedProminent)
                }

                if let result = viewModel.latestImportResult {
                    Divider()
                    Text("最近导入: \(result.importTaskId)")
                        .font(.subheadline.weight(.semibold))
                    Text("成功 \(result.successRecords) / \(result.totalRecords)，失败 \(result.failedRecords)")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var privacySection: some View {
        SectionCard(title: "隐私操作", subtitle: "当前后端仍是占位接口，但手机端已预留入口。") {
            VStack(alignment: .leading, spacing: 12) {
                Button("查看导出占位响应") {
                    Task {
                        await invokePrivacyExport()
                    }
                }
                .buttonStyle(.bordered)

                Button("查看删除占位响应") {
                    Task {
                        await invokePrivacyDelete()
                    }
                }
                .buttonStyle(.bordered)

                Text("iPhone 真机调试时，服务地址不能使用 localhost，应填写电脑的局域网 IP。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if let latestPrivacyMessage = viewModel.latestPrivacyMessage {
                    Divider()
                    Text(latestPrivacyMessage)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func reload() async {
        do {
            let client = try settings.makeClient()
            await viewModel.load(using: client)
        } catch {
            viewModel.setError(error.localizedDescription)
        }
    }

    private func invokePrivacyExport() async {
        do {
            let client = try settings.makeClient()
            await viewModel.requestPrivacyExport(using: client)
        } catch {
            viewModel.setPrivacyMessage(error.localizedDescription)
        }
    }

    private func invokePrivacyDelete() async {
        do {
            let client = try settings.makeClient()
            await viewModel.requestPrivacyDelete(using: client)
        } catch {
            viewModel.setPrivacyMessage(error.localizedDescription)
        }
    }

    private func handleImportSelection(_ result: Result<URL, Error>) async {
        do {
            let url = try result.get()
            let startedAccess = url.startAccessingSecurityScopedResource()
            defer {
                if startedAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            let fileData = try Data(contentsOf: url)
            let mimeType = UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let client = try settings.makeClient()

            await viewModel.submitImport(
                fileName: url.lastPathComponent,
                mimeType: mimeType,
                fileData: fileData,
                using: client
            )
        } catch {
            viewModel.setPrivacyMessage(error.localizedDescription)
        }
    }
}
