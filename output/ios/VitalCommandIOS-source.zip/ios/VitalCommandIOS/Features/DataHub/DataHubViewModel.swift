import Foundation
import SwiftUI
import VitalCommandMobileCore

@MainActor
final class DataHubViewModel: ObservableObject {
    @Published private(set) var state: LoadState<[HealthImportOption]> = .idle
    @Published var selectedImporter: ImporterKey = .annualExam
    @Published private(set) var latestImportResult: ImportExecutionResult?
    @Published private(set) var latestPrivacyMessage: String?

    func setError(_ message: String) {
        state = .failed(message)
    }

    func setPrivacyMessage(_ message: String) {
        latestPrivacyMessage = message
    }

    func load(using client: HealthAPIClient) async {
        if case .loading = state {
            return
        }

        state = .loading

        do {
            let dashboard = try await client.fetchDashboard()
            state = .loaded(dashboard.importOptions)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func submitImport(
        fileName: String,
        mimeType: String,
        fileData: Data,
        using client: HealthAPIClient
    ) async {
        do {
            latestImportResult = try await client.importData(
                importerKey: selectedImporter,
                fileName: fileName,
                mimeType: mimeType,
                fileData: fileData
            ).result
        } catch {
            latestPrivacyMessage = error.localizedDescription
        }
    }

    func requestPrivacyExport(using client: HealthAPIClient) async {
        do {
            let response = try await client.requestPrivacyExport(PrivacyExportRequest())
            latestPrivacyMessage = "导出占位返回: \(response.nextStep)"
        } catch {
            latestPrivacyMessage = error.localizedDescription
        }
    }

    func requestPrivacyDelete(using client: HealthAPIClient) async {
        do {
            let response = try await client.requestPrivacyDelete(PrivacyDeleteRequest())
            latestPrivacyMessage = "删除占位返回: \(response.nextStep)"
        } catch {
            latestPrivacyMessage = error.localizedDescription
        }
    }
}
