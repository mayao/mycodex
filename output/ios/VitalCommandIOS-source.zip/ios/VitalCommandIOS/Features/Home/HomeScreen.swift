import SwiftUI
import VitalCommandMobileCore

struct HomeScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @StateObject private var viewModel = HomeViewModel()

    var body: some View {
        NavigationStack {
            Group {
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("正在加载首页")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                case let .failed(message):
                    EmptyStateCard(
                        title: "首页暂时不可用",
                        message: message,
                        actionTitle: "重试"
                    ) {
                        Task { await reload() }
                    }
                    .padding()

                case let .loaded(payload):
                    ScrollView {
                        VStack(alignment: .leading, spacing: 18) {
                            summaryHeader(payload)
                            spotlightSection(payload)
                            sourceDimensionsSection(payload)
                            remindersSection(payload)
                            reportsSection(payload)
                        }
                        .padding(16)
                    }
                    .background(Color.appGroupedBackground)
                }
            }
            .navigationTitle("总览")
            .toolbar {
                NavigationLink("设置") {
                    SettingsScreen()
                }
            }
        }
        .task(id: settings.trimmedServerURLString) {
            await reload()
        }
    }

    private func reload() async {
        do {
            let client = try settings.makeClient()
            await viewModel.load(using: client)
        } catch {
            viewModel.setError(error.localizedDescription)
        }
    }

    private func summaryHeader(_ payload: HealthHomePageData) -> some View {
        SectionCard(title: payload.overviewHeadline, subtitle: payload.overviewNarrative) {
            VStack(alignment: .leading, spacing: 12) {
                Text(payload.latestNarrative.output.headline)
                    .font(.headline)

                InsightListSection(title: "优先动作", items: payload.latestNarrative.output.priorityActions)
            }
        }
    }

    private func spotlightSection(_ payload: HealthHomePageData) -> some View {
        SectionCard(title: "关键指标", subtitle: "手机端改为横向卡片，便于单手快速浏览。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.overviewSpotlights, id: \.id) { spotlight in
                        KeyValueTile(
                            label: spotlight.label,
                            value: spotlight.value,
                            detail: spotlight.detail,
                            tone: spotlight.tone
                        )
                    }
                }
            }
        }
    }

    private func sourceDimensionsSection(_ payload: HealthHomePageData) -> some View {
        SectionCard(title: "数据来源状态", subtitle: "把 Web 端的多列信息压缩为可横向滚动的来源卡。") {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(payload.sourceDimensions) { dimension in
                        DimensionChip(dimension: dimension)
                    }
                }
            }
        }
    }

    private func remindersSection(_ payload: HealthHomePageData) -> some View {
        SectionCard(title: "当前提醒", subtitle: payload.disclaimer) {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(payload.keyReminders) { item in
                    ReminderRow(item: item)
                    if item.id != payload.keyReminders.last?.id {
                        Divider()
                    }
                }
            }
        }
    }

    private func reportsSection(_ payload: HealthHomePageData) -> some View {
        SectionCard(title: "最近报告", subtitle: "报告详情在独立页面查看，避免手机端首页过长。") {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(payload.latestReports) { report in
                    NavigationLink {
                        ReportDetailScreen(reportID: report.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(report.title)
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                Spacer()
                                StatusBadge(
                                    text: report.reportType == .weekly ? "周报" : "月报",
                                    tint: report.reportType == .weekly ? .blue : .purple
                                )
                            }

                            Text(report.summary.output.headline)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
    }
}
