import SwiftUI
import VitalCommandMobileCore

struct ReportDetailScreen: View {
    let reportID: String

    @EnvironmentObject private var settings: AppSettingsStore
    @StateObject private var viewModel = ReportDetailViewModel()

    var body: some View {
        Group {
            switch viewModel.state {
            case .idle, .loading:
                ProgressView("正在加载报告详情")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

            case let .failed(message):
                EmptyStateCard(
                    title: "报告详情暂时不可用",
                    message: message,
                    actionTitle: "重试"
                ) {
                    Task { await reload() }
                }
                .padding()

            case let .loaded(report):
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        SectionCard(title: report.title, subtitle: "\(report.periodStart) 至 \(report.periodEnd)") {
                            Text(report.summary.output.headline)
                                .font(.headline)
                            Text(report.summary.output.disclaimer)
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }

                        SectionCard(title: "本期变化") {
                            InsightListSection(title: "重点变化", items: report.summary.output.mostImportantChanges)
                        }

                        SectionCard(title: "优先动作") {
                            InsightListSection(title: "行动建议", items: report.summary.output.priorityActions)
                        }

                        SectionCard(title: "结构化洞察", subtitle: "手机端以卡片分页呈现，减少单屏负载。") {
                            VStack(alignment: .leading, spacing: 14) {
                                ForEach(report.structuredInsights.insights.prefix(6)) { insight in
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack {
                                            Text(insight.title)
                                                .font(.headline)
                                            Spacer()
                                            StatusBadge(text: severityText(insight.severity), tint: severityColor(insight.severity))
                                        }

                                        Text(insight.evidence.summary)
                                            .font(.subheadline)
                                            .foregroundStyle(.secondary)

                                        Text("建议: \(insight.suggestedAction)")
                                            .font(.footnote.weight(.medium))
                                    }

                                    if insight.id != report.structuredInsights.insights.prefix(6).last?.id {
                                        Divider()
                                    }
                                }
                            }
                        }
                    }
                    .padding(16)
                }
                .background(Color.appGroupedBackground)
            }
        }
        .navigationTitle("报告详情")
        .appInlineNavigationTitle()
        .task(id: settings.trimmedServerURLString + reportID) {
            await reload()
        }
    }

    private func reload() async {
        do {
            let client = try settings.makeClient()
            await viewModel.load(reportID: reportID, using: client)
        } catch {
            viewModel.setError(error.localizedDescription)
        }
    }

    private func severityColor(_ severity: StructuredInsightSeverity) -> Color {
        switch severity {
        case .positive:
            return .green
        case .low:
            return .blue
        case .medium:
            return .orange
        case .high:
            return .red
        }
    }

    private func severityText(_ severity: StructuredInsightSeverity) -> String {
        switch severity {
        case .positive:
            return "积极"
        case .low:
            return "低"
        case .medium:
            return "中"
        case .high:
            return "高"
        }
    }
}
