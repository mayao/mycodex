import SwiftUI
import VitalCommandMobileCore

struct ReportsScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @StateObject private var viewModel = ReportsViewModel()

    var body: some View {
        NavigationStack {
            Group {
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("正在加载报告")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                case let .failed(message):
                    EmptyStateCard(
                        title: "报告列表暂时不可用",
                        message: message,
                        actionTitle: "重试"
                    ) {
                        Task { await reload() }
                    }
                    .padding()

                case .loaded:
                    List {
                        Picker("报告类型", selection: $viewModel.selectedKind) {
                            Text("周报").tag(ReportKind.weekly)
                            Text("月报").tag(ReportKind.monthly)
                        }
                        .pickerStyle(.segmented)
                        .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                        .listRowBackground(Color.clear)

                        ForEach(viewModel.visibleReports) { report in
                            NavigationLink {
                                ReportDetailScreen(reportID: report.id)
                            } label: {
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Text(report.title)
                                            .font(.headline)
                                        Spacer()
                                        Text(report.periodEnd)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }

                                    Text(report.summary.output.headline)
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(3)
                                }
                                .padding(.vertical, 6)
                            }
                        }
                    }
                    .appInsetGroupedListStyle()
                }
            }
            .navigationTitle("报告")
        }
        .task(id: settings.trimmedServerURLString) {
            await reload()
        }
    }

    private func reload() async {
        do {
            let client = try settings.makeClient()
            await viewModel.load(using: client)
        } catch {
            viewModel.setError(error.localizedDescription)
        }
    }
}
