import SwiftUI

struct SettingsScreen: View {
    @EnvironmentObject private var settings: AppSettingsStore

    var body: some View {
        Form {
            Section("服务地址") {
                TextField("http://192.168.1.10:3000/", text: $settings.serverURLString)
                    .appURLTextEntry()

                Text("iPhone 连接开发机时，请使用电脑的局域网 IP；不要填 localhost。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Section("适配策略") {
                Text("首页改为卡片 + 横向滚动，降低单屏信息密度。")
                Text("趋势页拆成独立 tab，避免首页图表过长。")
                Text("报告页使用列表 + 详情页，替代桌面端大块内容拼接。")
                Text("数据页集中上传、导出、删除，占用最少导航层级。")
            }
        }
        .navigationTitle("设置")
    }
}
