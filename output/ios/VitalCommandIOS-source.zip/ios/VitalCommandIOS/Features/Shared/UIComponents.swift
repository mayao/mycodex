import SwiftUI
import VitalCommandMobileCore

#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

struct StatusBadge: View {
    let text: String
    let tint: Color

    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .foregroundStyle(tint)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(tint.opacity(0.12), in: Capsule())
    }
}

struct SectionCard<Content: View>: View {
    let title: String
    let subtitle: String?
    @ViewBuilder let content: Content

    init(title: String, subtitle: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.title3.weight(.semibold))
                if let subtitle {
                    Text(subtitle)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }

            content
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.primary.opacity(0.08), lineWidth: 1)
        )
    }
}

struct KeyValueTile: View {
    let label: String
    let value: String
    let detail: String
    let tone: HealthTone

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(label)
                    .font(.subheadline.weight(.medium))
                Spacer()
                StatusBadge(text: toneText, tint: toneColor)
            }

            Text(value)
                .font(.headline.weight(.semibold))

            Text(detail)
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .frame(width: 180, alignment: .leading)
        .background(toneColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var toneColor: Color {
        switch tone {
        case .positive:
            return .green
        case .attention:
            return .orange
        case .neutral:
            return .blue
        }
    }

    private var toneText: String {
        switch tone {
        case .positive:
            return "积极"
        case .attention:
            return "关注"
        case .neutral:
            return "稳定"
        }
    }
}

struct ReminderRow: View {
    let item: HealthReminderItem

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                Text(item.title)
                    .font(.headline)
                Spacer()
                StatusBadge(text: severityText, tint: severityColor)
            }

            Text(item.summary)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text("建议: \(item.suggestedAction)")
                .font(.footnote.weight(.medium))
                .foregroundStyle(.primary)
        }
        .padding(.vertical, 4)
    }

    private var severityColor: Color {
        switch item.severity {
        case .positive:
            return .green
        case .low:
            return .blue
        case .medium:
            return .orange
        case .high:
            return .red
        }
    }

    private var severityText: String {
        switch item.severity {
        case .positive:
            return "积极"
        case .low:
            return "低"
        case .medium:
            return "中"
        case .high:
            return "高"
        }
    }
}

struct DimensionChip: View {
    let dimension: HealthSourceDimensionCard

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(dimension.label)
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Circle()
                    .fill(statusColor)
                    .frame(width: 8, height: 8)
            }

            Text(dimension.summary)
                .font(.footnote)
                .foregroundStyle(.secondary)

            Text(dimension.highlight)
                .font(.footnote.weight(.medium))
        }
        .padding(14)
        .frame(width: 170, alignment: .leading)
        .background(statusColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var statusColor: Color {
        switch dimension.status {
        case .ready:
            return .green
        case .attention:
            return .orange
        case .background:
            return .blue
        }
    }
}

struct EmptyStateCard: View {
    let title: String
    let message: String
    let actionTitle: String
    let action: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            Text(title)
                .font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button(actionTitle, action: action)
                .buttonStyle(.borderedProminent)
        }
        .padding(24)
        .frame(maxWidth: .infinity)
    }
}

struct InsightListSection: View {
    let title: String
    let items: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)

            ForEach(items, id: \.self) { item in
                HStack(alignment: .top, spacing: 10) {
                    Circle()
                        .fill(Color.accentColor)
                        .frame(width: 6, height: 6)
                        .padding(.top, 7)
                    Text(item)
                        .font(.subheadline)
                }
            }
        }
    }
}

struct SparklineShape: Shape {
    let values: [Double]

    func path(in rect: CGRect) -> Path {
        var path = Path()
        guard values.count > 1, let minValue = values.min(), let maxValue = values.max() else {
            return path
        }

        let span = max(maxValue - minValue, 0.0001)

        for (index, value) in values.enumerated() {
            let x = rect.minX + CGFloat(index) / CGFloat(values.count - 1) * rect.width
            let normalized = (value - minValue) / span
            let y = rect.maxY - CGFloat(normalized) * rect.height

            if index == 0 {
                path.move(to: CGPoint(x: x, y: y))
            } else {
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }

        return path
    }
}

struct TrendChartCard: View {
    let chart: HealthTrendChartModel

    var body: some View {
        SectionCard(title: chart.title, subtitle: chart.description) {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(chart.lines) { line in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(line.label)
                                .font(.subheadline.weight(.semibold))
                            Spacer()
                            if let latest = latestValue(for: line.key) {
                                Text("\(latest, specifier: "%.1f") \(line.unit)")
                                    .font(.footnote.weight(.medium))
                                    .foregroundStyle(.secondary)
                            }
                        }

                        SparklineShape(values: values(for: line.key))
                            .stroke(lineColor(line.color), style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                            .frame(height: 54)
                    }
                }
            }
        }
    }

    private func values(for key: String) -> [Double] {
        chart.data.compactMap { $0.values[key] }
    }

    private func latestValue(for key: String) -> Double? {
        values(for: key).last
    }

    private func lineColor(_ hex: String) -> Color {
        Color(hex: hex) ?? .accentColor
    }
}

private extension Color {
    init?(hex: String) {
        let normalized = hex.replacingOccurrences(of: "#", with: "")
        guard normalized.count == 6, let value = Int(normalized, radix: 16) else {
            return nil
        }

        self.init(
            red: Double((value >> 16) & 0xFF) / 255.0,
            green: Double((value >> 8) & 0xFF) / 255.0,
            blue: Double(value & 0xFF) / 255.0
        )
    }
}

extension Color {
    static var appGroupedBackground: Color {
        #if canImport(UIKit)
        Color(uiColor: .systemGroupedBackground)
        #elseif canImport(AppKit)
        Color(nsColor: .windowBackgroundColor)
        #else
        Color.gray.opacity(0.08)
        #endif
    }
}

extension View {
    @ViewBuilder
    func appInlineNavigationTitle() -> some View {
        #if canImport(UIKit)
        navigationBarTitleDisplayMode(.inline)
        #else
        self
        #endif
    }

    @ViewBuilder
    func appInsetGroupedListStyle() -> some View {
        #if canImport(UIKit)
        listStyle(.insetGrouped)
        #else
        listStyle(.inset)
        #endif
    }

    @ViewBuilder
    func appURLTextEntry() -> some View {
        #if canImport(UIKit)
        textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .keyboardType(.URL)
        #else
        self
        #endif
    }
}
