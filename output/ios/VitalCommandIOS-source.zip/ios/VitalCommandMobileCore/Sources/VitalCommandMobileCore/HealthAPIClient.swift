import Foundation

public struct AppServerConfiguration: Sendable, Equatable {
    public var baseURL: URL

    public init(baseURL: URL) {
        self.baseURL = baseURL
    }
}

public enum HealthAPIClientError: LocalizedError, Sendable {
    case invalidResponse
    case server(statusCode: Int, message: String)
    case transport(String)

    public var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "服务响应格式无效。"
        case let .server(_, message):
            return message
        case let .transport(message):
            return message
        }
    }
}

public protocol URLSessioning: Sendable {
    func data(for request: URLRequest) async throws -> (Data, URLResponse)
}

extension URLSession: URLSessioning {}

struct APIErrorEnvelope: Decodable {
    struct APIErrorPayload: Decodable {
        let id: String
        let message: String
    }

    let error: APIErrorPayload
}

public final class HealthAPIClient: @unchecked Sendable {
    private let configuration: AppServerConfiguration
    private let session: URLSessioning
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    public init(
        configuration: AppServerConfiguration,
        session: URLSessioning = URLSession.shared
    ) {
        self.configuration = configuration
        self.session = session

        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        self.decoder = decoder

        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        self.encoder = encoder
    }

    public func fetchDashboard() async throws -> HealthHomePageData {
        try await send(path: "api/dashboard")
    }

    public func fetchReports() async throws -> ReportsIndexData {
        try await send(path: "api/reports")
    }

    public func fetchReportDetail(snapshotId: String) async throws -> HealthReportSnapshotRecord {
        try await send(path: "api/reports/\(snapshotId.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? snapshotId)")
    }

    public func importData(
        importerKey: ImporterKey,
        fileName: String,
        mimeType: String,
        fileData: Data
    ) async throws -> ImportEnvelope {
        var body = MultipartFormDataBody()
        body.appendField(name: "importerKey", value: importerKey.rawValue)
        body.appendFile(name: "file", fileName: fileName, mimeType: mimeType, fileData: fileData)
        body.finalize()

        var request = makeRequest(path: "api/imports", method: "POST")
        request.setValue("multipart/form-data; boundary=\(body.boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body.data

        return try await send(request: request)
    }

    public func requestPrivacyExport(_ input: PrivacyExportRequest) async throws -> PrivacyPlaceholderResponse {
        try await sendJSON(path: "api/privacy/export", body: input, additionalAcceptedStatusCodes: [501])
    }

    public func requestPrivacyDelete(_ input: PrivacyDeleteRequest) async throws -> PrivacyPlaceholderResponse {
        try await sendJSON(path: "api/privacy/delete", body: input, additionalAcceptedStatusCodes: [501])
    }

    private func sendJSON<T: Decodable, Body: Encodable>(
        path: String,
        body: Body,
        additionalAcceptedStatusCodes: Set<Int> = []
    ) async throws -> T {
        var request = makeRequest(path: path, method: "POST")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(body)
        return try await send(request: request, additionalAcceptedStatusCodes: additionalAcceptedStatusCodes)
    }

    private func send<T: Decodable>(path: String) async throws -> T {
        try await send(request: makeRequest(path: path, method: "GET"))
    }

    private func send<T: Decodable>(
        request: URLRequest,
        additionalAcceptedStatusCodes: Set<Int> = []
    ) async throws -> T {
        let payload: Data
        let response: URLResponse

        do {
            (payload, response) = try await session.data(for: request)
        } catch {
            throw HealthAPIClientError.transport(error.localizedDescription)
        }

        guard let httpResponse = response as? HTTPURLResponse else {
            throw HealthAPIClientError.invalidResponse
        }

        guard (200 ..< 300).contains(httpResponse.statusCode) || additionalAcceptedStatusCodes.contains(httpResponse.statusCode) else {
            if let envelope = try? decoder.decode(APIErrorEnvelope.self, from: payload) {
                throw HealthAPIClientError.server(statusCode: httpResponse.statusCode, message: envelope.error.message)
            }

            throw HealthAPIClientError.server(statusCode: httpResponse.statusCode, message: "请求失败，状态码 \(httpResponse.statusCode)。")
        }

        do {
            return try decoder.decode(T.self, from: payload)
        } catch {
            throw HealthAPIClientError.transport("数据解析失败: \(error.localizedDescription)")
        }
    }

    private func makeRequest(path: String, method: String) -> URLRequest {
        let url = configuration.baseURL.appending(path: path)
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 30
        return request
    }
}

public struct ImportEnvelope: Codable, Sendable {
    public let result: ImportExecutionResult
}
